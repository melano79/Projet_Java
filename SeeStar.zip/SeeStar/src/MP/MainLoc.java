package MP;

import java.sql.SQLException;
import java.util.Scanner;

public class MainLoc {

	public static void main() {

        // Scanner global pour toute l'application
        Scanner scanner = new Scanner(System.in);

        // URL de la base SQLite
        String url = "jdbc:sqlite:java_sat_db.db";

        // Boucle permettant de relancer en cas d’erreur SQL
        while (true) {
            try {
                // Lancement du menu principal
                Start.debut(scanner, url);
                break;

            } catch (SQLException e) { // traitement des erreurs sqlite

                System.err.println("Erreur SQL : " + e.getMessage());
                System.out.println("Voulez-vous retenter ? (1 = oui)");

                String scans = scanner.nextLine();

                if (scans.equals("1")) {// demande pour recommencer ou non
                    System.out.println("Redémarrage du programme...\n");
                } else {// sortie du programme
                    System.out.println("fin du programme...\n");
                    break;
                }
            }
        }

        scanner.close();
    }
}
