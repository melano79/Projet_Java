package MP;

import java.awt.Color;
import java.sql.*;
import javax.swing.JLabel;

public class Authentification {
		private String url = "jdbc:mysql://localhost:3306/"; //ouvrir XAMPP pour le fonctionnement de l'url
		private static final String NOM_BDD = "db_satellites";
		private String user = "root";
		private String password = "";
		public Authentification() {}
		
		//creation de la base de données si elle n'est pas déjà existante
		public void bdd(JLabel error) {
			try (Connection conn = DriverManager.getConnection(url, user, password);
				 Statement stmt = conn.createStatement()){
				// 2. Création de la base de données si elle n'existe pas
	            String sqlCreateDB = "CREATE DATABASE IF NOT EXISTS " + NOM_BDD + 
	                                 " DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci";
	            stmt.executeUpdate(sqlCreateDB);
	            // 3. On indique qu'on veut utiliser cette base de données précise
	            stmt.executeUpdate("USE " + NOM_BDD+";");
	            // 4. Création de la table utilisateurs si elle n'existe pas
	            String sqlCreateTable = "CREATE TABLE IF NOT EXISTS utilisateurs ("
	                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
	                    + "pseudo VARCHAR(25) NOT NULL UNIQUE, "
	                    + "password VARCHAR(25) NOT NULL "
	                    + ")";
	            stmt.executeUpdate(sqlCreateTable);
			} catch(SQLException e) {
				error.setText("Erreur SQL : " + e.getMessage());
                error.setForeground(Color.RED);
			}
		}
		
		// Créer un compte
	    public boolean inscrire(String pseudo, String mdp, JLabel error) {
	    	String query = "INSERT INTO utilisateurs (pseudo, password) VALUES (?, ?)";
	        	try (Connection conn = DriverManager.getConnection(url+NOM_BDD, user, password);
	                    PreparedStatement pstmt = conn.prepareStatement(query)) {
	                   pstmt.setString(1, pseudo);
	                   pstmt.setString(2, mdp);
	                   pstmt.executeUpdate();
	                   
	                   return true;
	               } catch (SQLException e) {
	                   error.setText("Erreur SQL : " + e.getMessage());
	                   error.setForeground(Color.RED);
	                   return false;
	               }
	    }
	    
	 // Vérifier la connexion
	    public boolean connecter(String pseudo, String mdp,JLabel error ) {
	    	String query = "SELECT * FROM utilisateurs WHERE pseudo = ? AND password = ?";

	        try (Connection conn = DriverManager.getConnection(url+NOM_BDD, user, password);
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            pstmt.setString(1, pseudo);
	            pstmt.setString(2, mdp);
	            ResultSet rs = pstmt.executeQuery();
	            if(rs.next()) {
	            	return true;
	            }else {
	            	error.setText("Users not found or wrong password ");
	            	error.setForeground(Color.RED);
	            	return false;
	            }
	        } catch (SQLException e) {
                error.setText("Erreur SQL : " + e.getMessage());
                error.setForeground(Color.RED);
	            return false;
	        }
	    }
}
