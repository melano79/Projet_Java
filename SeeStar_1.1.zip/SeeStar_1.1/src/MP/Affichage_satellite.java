package MP;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Affichage_satellite {

    // Méthode principale d’affichage selon le tri choisi
    static void afficher(Statement requeteSQL, String conditionFiltre, int limite, Scanner clavier, int choixAffichage) throws SQLException {

        String choix = "";
        String requete = "";

        // Sélection du type de tri
        switch(choixAffichage) {

            case 1: // Affichage général
                requete = "SELECT * FROM NewTable "
                        + conditionFiltre
                        + " LIMIT " + limite + ";";
                break;

            case 2: // Tri par date
                choix = "[Date_of_Launch;]";
                requete = commandesqlNVARCHAR(limite, conditionFiltre, choix);
                break;

            case 3: // Tri par puissance
                choix = "[Power_watts;]";
                requete = commandesqlNVARCHAR(limite, conditionFiltre, choix);
                break;

            case 4: // Tri par masse
                choix = "[Launch_Mass_kg;]";
                requete = commandesqlNVARCHAR(limite, conditionFiltre, choix);
                break;

            case 5: // Tri par orbite
                choix = "[Type_of_Orbit;]";
                requete = commandesqlNVARCHAR(limite, conditionFiltre, choix);
                break;

            case 6: // Tri par site
                choix = "[Launch_Site;]";
                requete = commandesql(limite, conditionFiltre, choix);
                break;

            case 7: // Tri par commentaires
                choix = "[Comments;]";
                requete = commandesql(limite, conditionFiltre, choix);
                break;

            default:
                System.out.println("Commande inconnue ! Affichage général par défaut.");
                requete = "SELECT * FROM NewTable "
                        + conditionFiltre
                        + " LIMIT " + limite + ";";
                break;
        }

        // Exécution de la requête SQL
        ResultSet rs = requeteSQL.executeQuery(requete);

        int compteur = 0;

        // Affichage de chaque satellite
        while (rs.next()) {
            compteur++;
            System.out.println("Satellite n°" + compteur);
            afficherSatelliteComplet(rs);
        }

        rs.close();

        if (compteur == 0) {
            System.out.println("Aucun satellite trouvé !");
        }
    }

    // Requête SQL pour colonnes NVARCHAR (tri numérique)
    static String commandesqlNVARCHAR(int limite, String conditionFiltre, String choix) {

        if (conditionFiltre.equals("")) {
            return "SELECT * FROM NewTable "
                    + " WHERE " + choix + " IS NOT NULL "
                    + " ORDER BY CAST(" + choix + " AS REAL) DESC "
                    + " LIMIT " + limite + ";";
        } else {
            return "SELECT * FROM NewTable "
                    + conditionFiltre + " AND " + choix + " IS NOT NULL "
                    + " ORDER BY CAST(" + choix + " AS REAL) DESC "
                    + " LIMIT " + limite + ";";
        }
    }

    // Requête SQL pour colonnes VARCHAR
    static String commandesql(int limite, String conditionFiltre, String choix) {

        if (conditionFiltre.equals("")) {
            return "SELECT * FROM NewTable "
                    + " WHERE " + choix + " IS NOT NULL "
                    + " ORDER BY " + choix
                    + " LIMIT " + limite + ";";
        } else {
            return "SELECT * FROM NewTable "
                    + conditionFiltre
                    + " AND " + choix + " IS NOT NULL "
                    + " ORDER BY " + choix + " ASC "
                    + " LIMIT " + limite + ";";
        }
    }

    // Affichage complet d’un satellite (toutes les colonnes)
    static void afficherSatelliteComplet(ResultSet rs) throws SQLException {

        System.out.println(" - Utilisateurs : " + rs.getString("Users;"));
        System.out.println(" - Nom du satellite : " + rs.getString("Name_of_Satellite;"));
        System.out.println(" - Propriétaire / Opérateur : " + rs.getString("Operator_Owner;"));
        System.out.println(" - Inclinaison : " + rs.getString("Inclination;"));
        System.out.println(" - Date de lancement : " + rs.getString("Date_of_Launch;"));
        System.out.println(" - Durée de vie prévue : " + rs.getString("Expected_Lifetime_yrs;"));
        System.out.println(" - Constructeur : " + rs.getString("Contractor;"));
        System.out.println(" - Commentaires : " + rs.getString("Comments;"));
        System.out.println(" - Site de lancement : " + rs.getString("Launch_Site;"));
        System.out.println(" - Puissance (watts) : " + rs.getString("Power_watts;"));
        System.out.println(" - Masse (kg) : " + rs.getString("Launch_Mass_kg;"));
        System.out.println(" - Type d’orbite : " + rs.getString("Type_of_Orbit;"));
        System.out.println("----------------------------------------------");
    }
}
