package MP;

import java.util.Scanner;

public class GUI {

    public static void main(String[] args) {
        // Toujours lancer l'interface graphique dans l'Event Dispatch Thread
    	
    	System.out.println("---------------------------- Binevenu dans SeeStar -----------------------------");
    	System.out.println("Souhaitez-vous utilisez la Base de Données locale ou la Base de Données distante");
    	System.out.println("                           (travail sur console)         (travail en graphique)");
    	System.out.println("                                 (entrez 0)                    (entrez 1)");
    	while(true) {
    		try (Scanner scanner = new Scanner(System.in)) {
				int res = scanner.nextInt();
				switch (res) {
				case 0:
					MainLoc.main();
					return;
				case 1:
				    Interface.create();
				    return;
				default:
					System.out.println("Commande inconnu. Lancement de l'interface graphique.");
				    Interface.create();
				    return;
				}
			}
    	}
    }
}
