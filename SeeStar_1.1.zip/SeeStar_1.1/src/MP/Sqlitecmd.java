package MP;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Sqlitecmd {

    // Terminal SQL manuel (mode f1)
    static void commandeseuls(Scanner scanner, Statement stmt) throws SQLException {


            System.out.println("faire requête SQL avec (*)\n");

            // Lecture de la requête SQL brute
            String executequery = scanner.nextLine();

            // Exécution de la requête
            ResultSet rs = stmt.executeQuery(executequery);

            // Demande de la colonne à afficher
            System.out.println("que voulez vous afficher? \n");
            String nextaffichage = scanner.nextLine();

            System.out.println("il sera affiché : " + nextaffichage + "");

            // Affichage ligne par ligne
            while (rs.next()) {
                System.out.println(rs.getString(nextaffichage));
            }

            rs.close();

        
    }
}
