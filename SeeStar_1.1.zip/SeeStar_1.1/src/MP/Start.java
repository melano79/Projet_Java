package MP;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;

public class Start {


    // Méthode principale du menu
    static void debut(Scanner scanner, String url) throws SQLException {

        while (true) {

            // Connexion à la base SQLite
            Connection conn = DriverManager.getConnection(url);
            System.out.println("Connexion établie avec la base SQLite.");

            // Statement pour exécuter les requêtes SQL
            Statement stmt = conn.createStatement();

            // Menu principal
            System.out.println("bonjour bienvenus dans seastars");
            System.out.print("Commande : \n");
            System.out.print("f1 : terminal de commandes\n");
            System.out.print("play : terminal guidé\n");
            System.out.print("exit : quitter\n");

            // Lecture de la commande
            String cmd = scanner.nextLine();

            switch (cmd) {

                case "f1":
                    Sqlitecmd.commandeseuls(scanner, stmt);
                    break;

                case "play":
                	Commandes_guide.commandesGuide(scanner, stmt);
                	break;

                case "exit":
                    System.out.println("Fin du programme.");
                    return;

                default:
                    System.out.println("Commande inconnue.");
            }

            // Fermeture des ressources
            stmt.close();
            conn.close();
        }
    }
}
