import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Commandes_guide {

    // Méthode principale du mode "play" (commandes guidées)
    static void commandesGuide(Scanner clavier, Statement requeteSQL) throws SQLException {

        while (true) {

            System.out.println("==============================================");
            System.out.println("   BIENVENUE DANS LES COMMANDES GUIDÉES");
            System.out.println("==============================================\n");

            // Demande d’un filtre sur un type de satellite
            System.out.println("Souhaitez-vous afficher un type de satellite en particulier ?");
            System.out.println("(Exemples : Starlink, NASA, ESA, China, etc...)");
            System.out.println("Tapez * ou laissez vide pour afficher tous les satellites.");
            System.out.print("Votre choix : ");
            String demandesate = clavier.nextLine().trim();

            // Condition SQL optionnelle
            String conditionFiltre = "";

            // Si l’utilisateur a entré un filtre, on construit la condition SQL
            if (!demandesate.equals("") && !demandesate.equals("*")) {
                conditionFiltre = "WHERE [Operator_Owner;] LIKE '%" + demandesate + "%' "
                                + "OR [Name_of_Satellite;] LIKE '%" + demandesate + "%' "
                                + "OR [Users;] LIKE '%" + demandesate + "%'";
            }

            // Choix du nombre de résultats
            System.out.println("\nCombien de satellites voulez-vous afficher ?");
            System.out.print("Votre choix : ");

            int limite = 10; // valeur par défaut
            try {
                limite = clavier.nextInt();
                if (limite < 0) {
                	System.err.println("Commande < 0. Valeur par défaut : 10 satellites.");
                	limite = 10;
                }
            } catch (Exception e) {
                System.out.println("Commande inconnue. Valeur par défaut : 10 satellites.");
            }
            clavier.nextLine(); // vide le buffer

            // Menu du type d’affichage
            System.out.println("\nChoisissez le type d’affichage :");
            System.out.println("1 - Affichage général");
            System.out.println("2 - Par date de lancement");
            System.out.println("3 - Par puissance (watts)");
            System.out.println("4 - Par poids (kg)");
            System.out.println("5 - Par type d’orbite");
            System.out.println("6 - Par site de lancement");
            System.out.println("7 - Par commentaires");
            System.out.print("Votre choix : ");

            int choixAffichage = 1;

            // Sécurisation de la saisie
            while (true) {
                try {
                    choixAffichage = clavier.nextInt();
                    break;
                } catch (Exception e) {
                    System.err.println("Erreur : veuillez entrer un nombre entier !");
                    clavier.nextLine();
                }
            }

            // Appel de la classe d’affichage
            Affichage_satellite.afficher(requeteSQL, conditionFiltre, limite, clavier, choixAffichage);

            // Demande si l’utilisateur veut recommencer
            System.out.println("\nVoulez-vous faire une nouvelle commande ? (0 = non / 1 = oui)");
            int recommencer = clavier.nextInt();
            clavier.nextLine();

            if (recommencer == 0) {
                System.out.println("Retour au menu principal...");
                String url = "jdbc:sqlite:C:\\Users\\mathi\\Desktop\\java_db\\chiant.db";
                Start.debut(clavier, url);
                break;
            }
        }
    }
}
