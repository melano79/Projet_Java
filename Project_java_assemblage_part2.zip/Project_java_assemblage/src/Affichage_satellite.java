import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Affichage_satellite {

    // ============================================================
    //  AFFICHAGE GENERAL : affiche simplement les satellites trouvés
    // ============================================================
    static void afficherListe(Statement requeteSQL, String conditionFiltre, int limite) throws SQLException {

        // Construction de la requête SQL avec filtre + limite
        String requete = "SELECT * FROM NewTable " + conditionFiltre + " LIMIT " + limite + ";";

        ResultSet rs = requeteSQL.executeQuery(requete);
        int compteur = 0;

        // Parcours des résultats
        while (rs.next()) {
            compteur++;
            System.out.println("Satellite n°" + compteur);
            afficherSatelliteComplet(rs); // Affichage détaillé
        }

        rs.close();
    }

    // ============================================================
    //  AFFICHAGE TRIE PAR DATE DE LANCEMENT (du plus récent au plus ancien)
    // ============================================================
    static void afficherParDate(Statement requeteSQL, String conditionFiltre, int limite, Scanner clavier) throws SQLException {

        // ORDER BY DESC = du plus récent au plus ancien
        String requete = "SELECT * "
                       + "FROM NewTable " + conditionFiltre
                       + " ORDER BY [Date_of_Launch;] DESC LIMIT " + limite + ";";

        ResultSet rs = requeteSQL.executeQuery(requete);

        int compteur = 0;
        while (rs.next()) {
            compteur++;
            System.out.println("Satellite n°" + compteur);
            afficherSatelliteComplet(rs);
        }

        rs.close();
    }

    // ============================================================
    //  AFFICHAGE TRIE PAR PUISSANCE (watts)
    // ============================================================
    static void afficherParPuissance(Statement requeteSQL, String conditionFiltre, int limite, Scanner clavier) throws SQLException {

        // Tri décroissant : les satellites les plus puissants en premier
        String requete = "SELECT * "
                       + "FROM NewTable " + conditionFiltre
                       + " ORDER BY [Power_watts;] DESC LIMIT " + limite + ";";

        ResultSet rs = requeteSQL.executeQuery(requete);

        int compteur = 0;
        while (rs.next()) {
            compteur++;
            System.out.println("Satellite n°" + compteur);
            afficherSatelliteComplet(rs);
        }

        rs.close();
    }

    // ============================================================
    //  AFFICHAGE TRIE PAR MASSE AU LANCEMENT
    // ============================================================
    static void afficherParPoids(Statement requeteSQL, String conditionFiltre, int limite, Scanner clavier) throws SQLException {

        // Tri décroissant : les satellites les plus lourds en premier
        String requete = "SELECT * "
                       + "FROM NewTable " + conditionFiltre
                       + " ORDER BY [Launch_Mass_kg;] DESC LIMIT " + limite + ";";

        ResultSet rs = requeteSQL.executeQuery(requete);

        int compteur = 0;
        while (rs.next()) {
            compteur++;
            System.out.println("Satellite n°" + compteur);
            afficherSatelliteComplet(rs);
        }

        rs.close();
    }

    // ============================================================
    //  AFFICHAGE TRIE PAR TYPE D’ORBITE (ordre alphabétique)
    // ============================================================
    static void afficherParOrbite(Statement requeteSQL, String conditionFiltre, int limite, Scanner clavier) throws SQLException {

        String requete = "SELECT * "
                       + "FROM NewTable " + conditionFiltre
                       + " ORDER BY [Type_of_Orbit;] ASC LIMIT " + limite + ";";

        ResultSet rs = requeteSQL.executeQuery(requete);

        int compteur = 0;
        while (rs.next()) {
            compteur++;
            System.out.println("Satellite n°" + compteur);
            afficherSatelliteComplet(rs);
        }
    }

    // ============================================================
    //  AFFICHAGE TRIE PAR SITE DE LANCEMENT
    // ============================================================
    static void afficherParSite(Statement requeteSQL, String conditionFiltre, int limite, Scanner clavier) throws SQLException {

        String requete = "SELECT * "
                       + "FROM NewTable " + conditionFiltre
                       + " ORDER BY [Launch_Site;] ASC LIMIT " + limite + ";";

        ResultSet rs = requeteSQL.executeQuery(requete);

        int compteur = 0;
        while (rs.next()) {
            compteur++;
            System.out.println("Satellite n°" + compteur);
            afficherSatelliteComplet(rs);
        }

        rs.close();
    }

    // ============================================================
    //  AFFICHAGE TRIE PAR COMMENTAIRES (ordre alphabétique)
    // ============================================================
    static void afficherParCommentaires(Statement requeteSQL, String conditionFiltre, int limite, Scanner clavier) throws SQLException {

        String requete = "SELECT * "
                       + "FROM NewTable " + conditionFiltre
                       + " ORDER BY [Comments;] ASC LIMIT " + limite + ";";

        ResultSet rs = requeteSQL.executeQuery(requete);

        int compteur = 0;
        while (rs.next()) {
            compteur++;
            System.out.println("Satellite n°" + compteur);
            afficherSatelliteComplet(rs);
        }
    }

    // ============================================================
    //  AFFICHAGE COMPLET D’UN SATELLITE (appelé par toutes les méthodes)
    // ============================================================
    static void afficherSatelliteComplet(ResultSet rs) throws SQLException {

        // Chaque champ correspond à une colonne de ta table SQLite
        System.out.println(" - Utilisateurs : " + rs.getString("Users;"));
        System.out.println(" - Nom du satellite : " + rs.getString("Name_of_Satellite;"));
        System.out.println(" - Propriétaire / Opérateur : " + rs.getString("Operator_Owner;"));
        System.out.println(" - Inclinaison : " + rs.getString("Inclination;"));
        System.out.println(" - Date de lancement : " + rs.getString("Date_of_Launch;"));
        System.out.println(" - Durée de vie prévue : " + rs.getString("Expected_Lifetime_yrs;"));
        System.out.println(" - Constructeur : " + rs.getString("Contractor;"));
        System.out.println(" - Commentaires : " + rs.getString("Comments;"));
        System.out.println(" - Site de lancement : " + rs.getString("Launch_Site;"));
        System.out.println(" - Puissance (watts) : " + rs.getString("Power_watts;"));
        System.out.println(" - Masse (kg) : " + rs.getString("Launch_Mass_kg;"));
        System.out.println(" - Type d’orbite : " + rs.getString("Type_of_Orbit;"));
        System.out.println("----------------------------------------------");
    }
}
