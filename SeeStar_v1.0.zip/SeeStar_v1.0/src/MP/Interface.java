package MP;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class Interface {
	//Pseudo global
    static String name ="";
    //Creation des pages globales
    static JFrame SeeStar_Page_Acceuil = new JFrame();
    static JFrame SeeStar_Page_Principal_BDD_Distante = new JFrame();
    static JFrame SeeStar_Page_Sat_Met = new JFrame();
    static JFrame SeeStar_Page_Sat_StL = new JFrame();
    static JFrame SeeStar_Page_Sat_GPS = new JFrame();
    
    //Gestion des liens en les pages
    static ActionListener ouvrir_Page_Acceuil = e -> {
    	SeeStar_Page_Acceuil.setVisible(true);
	    SeeStar_Page_Principal_BDD_Distante.setVisible(false);
	    SeeStar_Page_Sat_Met.setVisible(false);
	    SeeStar_Page_Sat_StL.setVisible(false);
	    SeeStar_Page_Sat_GPS.setVisible(false);
	};
    static ActionListener ouvrir_BDD_Distant = e -> {
    	SeeStar_Page_Acceuil.setVisible(false);
	    SeeStar_Page_Principal_BDD_Distante.setVisible(true);
	    SeeStar_Page_Sat_Met.setVisible(false);
	    SeeStar_Page_Sat_StL.setVisible(false);
	    SeeStar_Page_Sat_GPS.setVisible(false);
	};
	static ActionListener ouvrir_Met = e -> {
    	SeeStar_Page_Acceuil.setVisible(false);
	    SeeStar_Page_Principal_BDD_Distante.setVisible(false);
	    SeeStar_Page_Sat_Met.setVisible(true);
	    SeeStar_Page_Sat_StL.setVisible(false);
	    SeeStar_Page_Sat_GPS.setVisible(false);
	};
	static ActionListener ouvrir_StL = e -> {
    	SeeStar_Page_Acceuil.setVisible(false);
	    SeeStar_Page_Principal_BDD_Distante.setVisible(false);
	    SeeStar_Page_Sat_Met.setVisible(false);
	    SeeStar_Page_Sat_StL.setVisible(true);
	    SeeStar_Page_Sat_GPS.setVisible(false);
	};
	static ActionListener ouvrir_GPS = e -> {
    	SeeStar_Page_Acceuil.setVisible(false);
	    SeeStar_Page_Principal_BDD_Distante.setVisible(false);
	    SeeStar_Page_Sat_Met.setVisible(false);
	    SeeStar_Page_Sat_StL.setVisible(false);
	    SeeStar_Page_Sat_GPS.setVisible(true);
	};    
    
    public void create() {
        // Toujours lancer l'interface graphique dans l'Event Dispatch Thread
        SwingUtilities.invokeLater(Interface::create_SeeStar_Page_Acceuil);
        SwingUtilities.invokeLater(Interface::create_SeeStar_Page_Principal_BDD_Distante);
        SwingUtilities.invokeLater(Interface::create_SeeStar_Page_Sat_Met);
        SwingUtilities.invokeLater(Interface::create_SeeStar_Page_Sat_StL);
        SwingUtilities.invokeLater(Interface::create_SeeStar_Page_Sat_GPS);

    }

    private static void create_SeeStar_Page_Acceuil() {
    	// Création de la fenêtre d'acceuil
    	SeeStar_Page_Acceuil = new JFrame("SeeStar - Bienvenu");
    	
    	//Manière de fermer la fenêtre d'acceuil (quitter la fenêtre)
        SeeStar_Page_Acceuil.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Taille de la fenêtre (longueur, largeur)
        SeeStar_Page_Acceuil.setSize(800, 300);
        
        // Centrer les fenêtres
        SeeStar_Page_Acceuil.setLocationRelativeTo(null);
        
        // Création des composants de la fenêtre d'acceuil
        JPanel panel = new JPanel();
        panel.setBackground(new Color(40,40,40));
        
        JLabel Bienvenu = new JLabel("----- Bienvenu dans SeeStar -----", SwingConstants.CENTER);
        Bienvenu.setForeground(Color.WHITE);
        JTextField Pseudo = new JTextField(15);
        Pseudo.setBorder(BorderFactory.createTitledBorder("Pseudo"));
        JTextField champMDP = new JPasswordField(15);
        champMDP.setBorder(BorderFactory.createTitledBorder("Mot de passe"));
        
        JLabel resultLabel = new JLabel("", SwingConstants.CENTER);
        
        JButton btnConnexion = new JButton("Se connecter");
        btnConnexion.setBackground(new Color(9, 50, 100));
        btnConnexion.setForeground(Color.WHITE);
        btnConnexion.setBounds(5,200,400,50);
        JButton btnInscription = new JButton("S'inscrire");
        btnInscription.setBackground(new Color(9, 132, 227));
        btnInscription.setForeground(Color.WHITE);
        btnInscription.setBounds(400,200,400,50);
        
        
        JButton Entrer_ds_SeeStar_BDD_distant = new JButton("Utiliser une BDD Distante");
        Entrer_ds_SeeStar_BDD_distant.addActionListener(ouvrir_BDD_Distant);
        JButton Entrer_ds_SeeStar_BDD_locale = new JButton("Utiliser une BDD Locale");
        
        // Organisation des composants de la fenêtre d'acceuil dans un layout
        panel.setLayout(new GridLayout(6, 1, 5, 5));
        		//(Lignes, Colonnes, espace_entre_lignes, espace_entre_colonnes)
        panel.add(Bienvenu);
        panel.add(Pseudo);
        panel.add(champMDP);
        panel.add(resultLabel);
        JPanel panelbtn = new JPanel();
        panelbtn.setBackground(new Color(40,40,40));
        panelbtn.setLayout(new GridLayout(1, 2, 20, 20));
        panelbtn.add(btnConnexion);
        panelbtn.add(btnInscription);
        panel.add(panelbtn);
        SeeStar_Page_Acceuil.add(panel);

        // Affichage de la fenêtre d'acceuil
        SeeStar_Page_Acceuil.setVisible(true);
        
        
        // Gestion de l'événement du bouton 1 de la fenêtre d'acceuil
        btnConnexion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            Authentification A = new Authentification();
            String name = Pseudo.getText().trim();
            String psw = champMDP.getText().trim();
                if (A.connecter(name, psw,resultLabel)==false) {
                } else {
                  //On efface le contenu de la page précédente
                	panel.remove(Bienvenu);
                	panel.remove(Pseudo);
                	panel.remove(champMDP);
                	panel.remove(panelbtn);
                	panel.remove(resultLabel);
                	panel.revalidate();
                	panel.repaint();
                    
                  //On remplit à nouveau
                	panel.add(new JLabel());
                	panel.add(Bienvenu);
                	panel.add(resultLabel);
                    resultLabel.setText("Bonjour, " + name + " !");
                    resultLabel.setForeground(Color.YELLOW);
                    panel.add(Bienvenu);
                    panel.add(Entrer_ds_SeeStar_BDD_distant);
                    panel.add(Entrer_ds_SeeStar_BDD_locale);
                }
            }
        });
        
        btnInscription.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	Authentification A = new Authentification();
                String name = Pseudo.getText().trim();
                String psw = champMDP.getText().trim();
                if (A.inscrire(name, psw,resultLabel)==false) {
                    
                } else {
                    //On efface le contenu de la page précédente
                  	panel.remove(Bienvenu);
                  	panel.remove(Pseudo);
                  	panel.remove(champMDP);
                  	panel.remove(panelbtn);
                  	panel.remove(resultLabel);
                  	panel.revalidate();
                  	panel.repaint();
                      
                    //On remplit à nouveau
                  	panel.add(new JLabel());
                  	panel.add(Bienvenu);
                  	panel.add(resultLabel);
                    resultLabel.setText("Bonjour, " + name + " !");
                    resultLabel.setForeground(Color.YELLOW);
                    panel.add(Bienvenu);
                    panel.add(Entrer_ds_SeeStar_BDD_distant);
                    panel.add(Entrer_ds_SeeStar_BDD_locale);
                  }
    }
});

    }
    
    private static void create_SeeStar_Page_Principal_BDD_Distante() {
    	//Creation de la fenetre principale des BDD distantes
        SeeStar_Page_Principal_BDD_Distante = new JFrame("SeeStar - Page principale BDD distantes");

    	//Manière de fermer la fenêtre d'acceuil (quitter la fenêtre)
        SeeStar_Page_Principal_BDD_Distante.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Taille de la fenêtre (longueur, largeur)
        SeeStar_Page_Principal_BDD_Distante.setSize(800, 500);

        // Centrer la fenetre
        SeeStar_Page_Principal_BDD_Distante.setLocationRelativeTo(null);

        // Création des composants de la fenêtre d'acceuil de BDD distante
    	JLabel Choix_Type_Satellite = new JLabel("<html><div style='text-align: center;'>Choisissez le type "
    										   + "de satellite dont vous souhaitez obtenir des informations</div></html>",
    										   SwingConstants.CENTER);
    	Choix_Type_Satellite.setForeground(Color.WHITE);
    
    
    	// Organisation des composants de la fenêtre d'acceuil de BDD distante dans un layout
    	SeeStar_Page_Principal_BDD_Distante.setLayout(new GridLayout(2, 1));
    
    	//Ligne 1
    	JPanel top_Accueil_BDD_Distante = new JPanel(new GridLayout(1, 1));
    	top_Accueil_BDD_Distante.setBackground(new Color(40,40,40));
    	top_Accueil_BDD_Distante.add(Choix_Type_Satellite);
    	//Ligne 2
    	JPanel bot_Acceuil_BDD_Distante = new JPanel(new GridLayout(1, 3, 10, 0));
    	bot_Acceuil_BDD_Distante.setBorder(new EmptyBorder(10, 10, 10, 10)); // espace au-dessus
    	bot_Acceuil_BDD_Distante.setBackground(new Color(40,40,40));
    	JButton SatMet = new JButton("Satellites météo");
    	SatMet.addActionListener(ouvrir_Met);
    	bot_Acceuil_BDD_Distante.add(SatMet);
    	JButton SatStL = new JButton("Satellites StarLink");
    	SatStL.addActionListener(ouvrir_StL);
    	bot_Acceuil_BDD_Distante.add(SatStL);
    	JButton SatGPS = new JButton("Satellites GPS");
    	SatGPS.addActionListener(ouvrir_GPS);
    	bot_Acceuil_BDD_Distante.add(SatGPS);

    	//Rassemblement des lignes
    	SeeStar_Page_Principal_BDD_Distante.add(top_Accueil_BDD_Distante);
    	SeeStar_Page_Principal_BDD_Distante.add(bot_Acceuil_BDD_Distante);

    }
    
    private static void create_SeeStar_Page_Sat_Met() {
    	// Création de la fenêtre Meteo
    	SeeStar_Page_Sat_Met = new JFrame("SeeStar - Satellites GPS");
    	
    	//Manière de fermer la fenêtre Meteo (quitter la fenêtre)
    	SeeStar_Page_Sat_Met.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Taille de la fenêtre (longueur, largeur)
    	SeeStar_Page_Sat_Met.setSize(800, 500);

        // Centrer la fenêtre Meteo
    	SeeStar_Page_Sat_Met.setLocationRelativeTo(null);
        
        // Création des composants de la fenêtre Meteo
        //Une zone de texte
		JLabel Pres_lst_sat_météo = new JLabel("<html><div style='text-align: center;'>Voici une liste d'éléments de la base sélectionné : météo</div></html>", SwingConstants.CENTER);
		
		// Sélection de l'URL du site Meteo
		String urlCible = "https://celestrak.org/NORAD/elements/weather.txt";
		ArrayList<Satellite> liste = telecharger(urlCible);

		// TABLEAU
		String[] colonnes = {"Nom", "ID", "Inclinaison"};
		DefaultTableModel model = new DefaultTableModel(colonnes, 0);
		JTable table_met = new JTable(model);

		// Remplissage du tableau
		for (Satellite sat : liste) {
		    model.addRow(new Object[]{
		        sat.getNom(),
		        sat.getId(),
		        sat.getInclinaison()
		    });
		}

		// Scroll
		JScrollPane scrollPane = new JScrollPane(table_met);

		// STYLE
		table_met.setRowHeight(25);
		table_met.setFont(new Font("Arial", Font.PLAIN, 14));
		table_met.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));

		// Centrer Nom + ID + Inclinaison
		DefaultTableCellRenderer center = new DefaultTableCellRenderer();
		center.setHorizontalAlignment(JLabel.CENTER);

		table_met.getColumnModel().getColumn(0).setCellRenderer(center);
		table_met.getColumnModel().getColumn(1).setCellRenderer(center);
		table_met.getColumnModel().getColumn(2).setCellRenderer(center);
		
		// Tri auto des lignes en cliquant dessus
		table_met.setAutoCreateRowSorter(true);


		// Organisation des composants de la fenêtre Meteo dans un layout
		SeeStar_Page_Sat_Met.setLayout(new GridLayout(2, 1, 10, 10));

		//Ligne 1
		//Répartition en 2 colonnes
		JPanel top_SeeStar_Page_Sat_Meteo = new JPanel(new GridLayout(1, 2));
		top_SeeStar_Page_Sat_Meteo.setBackground(new Color(40,40,40));
		//Colonne 1
		top_SeeStar_Page_Sat_Meteo.add(Pres_lst_sat_météo);
		//Colonne 2
		JPanel zone_onglet_top_SeeStar_Page_Sat_Meteo = new JPanel(new GridLayout(12,1));
		zone_onglet_top_SeeStar_Page_Sat_Meteo.setBackground(new Color(40,40,40));
		zone_onglet_top_SeeStar_Page_Sat_Meteo.setBackground(new Color(40,40,40));
		zone_onglet_top_SeeStar_Page_Sat_Meteo.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10),
																						  BorderFactory.createLineBorder(Color.BLACK) ));
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(new JLabel());
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(new JLabel("<html><div style='text-align: center;'>Accès aux autres onglets</div></html>", SwingConstants.CENTER));
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(new JLabel());
    	JButton SatStL = new JButton("Satellites StarLink");
    	SatStL.addActionListener(ouvrir_StL);
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(SatStL);
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(new JLabel());
    	JButton SatGPS = new JButton("Satellites GPS");
    	SatGPS.addActionListener(ouvrir_GPS);
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(SatGPS);
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(new JLabel());
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(new JLabel("<html><div style='text-align: center;'>Retour aux choix de BDD</div></html>", SwingConstants.CENTER));
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(new JLabel());
    	JButton Retour = new JButton("Retour à la page principale");
    	Retour.addActionListener(ouvrir_Page_Acceuil);
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(Retour);
		zone_onglet_top_SeeStar_Page_Sat_Meteo.add(new JLabel());
		top_SeeStar_Page_Sat_Meteo.add(zone_onglet_top_SeeStar_Page_Sat_Meteo);
		
		// Ligne 2
		JPanel bot_SeeStar_Page_Sat_Meteo = new JPanel(new BorderLayout());
		bot_SeeStar_Page_Sat_Meteo.setBackground(new Color(40,40,40));
		scrollPane.setBorder(BorderFactory.createCompoundBorder(
			    BorderFactory.createEmptyBorder(5, 5, 5, 5),
			    BorderFactory.createLineBorder(new Color(40,40,40))
			));
		bot_SeeStar_Page_Sat_Meteo.add(scrollPane, BorderLayout.CENTER);

		//Rassemblement des lignes
		SeeStar_Page_Sat_Met.add(top_SeeStar_Page_Sat_Meteo);
		SeeStar_Page_Sat_Met.add(bot_SeeStar_Page_Sat_Meteo);

		SeeStar_Page_Sat_Met.revalidate();
		SeeStar_Page_Sat_Met.repaint();
    }

    private static void create_SeeStar_Page_Sat_StL() {
    	// Création de la fenêtre Meteo
        SeeStar_Page_Sat_StL = new JFrame("SeeStar - Satellites StarLink");
    	
    	//Manière de fermer la fenêtre Meteo (quitter la fenêtre)
    	SeeStar_Page_Sat_StL.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Taille de la fenêtre (longueur, largeur)
    	SeeStar_Page_Sat_StL.setSize(800, 500);

        // Centrer la fenêtre Meteo
    	SeeStar_Page_Sat_StL.setLocationRelativeTo(null);
        
        // Création des composants de la fenêtre Meteo
        //Une zone de texte
		JLabel Pres_lst_sat_starlink = new JLabel("<html><div style='text-align: center;'>Voici une liste d'éléments de la base sélectionné : StarLink</div></html>", SwingConstants.CENTER);
		
		// Sélection de l'URL du site Meteo
		String urlCible = "https://celestrak.org/NORAD/elements/starlink.txt";
		ArrayList<Satellite> liste = telecharger(urlCible);

		// TABLEAU
		String[] colonnes = {"Nom", "ID", "Inclinaison"};
		DefaultTableModel model = new DefaultTableModel(colonnes, 0);
		JTable table_stl = new JTable(model);

		// Remplissage du tableau
		for (Satellite sat : liste) {
		    model.addRow(new Object[]{
		        sat.getNom(),
		        sat.getId(),
		        sat.getInclinaison()
		    });
		}

		// Scroll
		JScrollPane scrollPane = new JScrollPane(table_stl);

		// STYLE
		table_stl.setRowHeight(25);
		table_stl.setFont(new Font("Arial", Font.PLAIN, 14));
		table_stl.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));

		// Centrer Nom + ID + Inclinaison
		DefaultTableCellRenderer center = new DefaultTableCellRenderer();
		center.setHorizontalAlignment(JLabel.CENTER);

		table_stl.getColumnModel().getColumn(0).setCellRenderer(center);
		table_stl.getColumnModel().getColumn(1).setCellRenderer(center);
		table_stl.getColumnModel().getColumn(2).setCellRenderer(center);
		
		// Tri auto des lignes en cliquant dessus
		table_stl.setAutoCreateRowSorter(true);


		// Organisation des composants de la fenêtre Meteo dans un layout
		SeeStar_Page_Sat_StL.setLayout(new GridLayout(2, 1, 10, 10));

		//Ligne 1
		//Répartition en 2 colonnes
		JPanel top_SeeStar_Page_Sat_StarLink = new JPanel(new GridLayout(1, 2));
		top_SeeStar_Page_Sat_StarLink.setBackground(new Color(40,40,40));
		//Colonne 1
		top_SeeStar_Page_Sat_StarLink.add(Pres_lst_sat_starlink);
		//Colonne 2
		JPanel zone_onglet_top_SeeStar_Page_Sat_StarLink = new JPanel(new GridLayout(12,1));
		zone_onglet_top_SeeStar_Page_Sat_StarLink.setBackground(new Color(40,40,40));
		zone_onglet_top_SeeStar_Page_Sat_StarLink.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10),
				  BorderFactory.createLineBorder(Color.BLACK) ));
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(new JLabel());
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(new JLabel("<html><div style='text-align: center;'>Accès aux autres onglets</div></html>", SwingConstants.CENTER));
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(new JLabel());
		JButton SatMet = new JButton("Satellites Météo");
		SatMet.addActionListener(ouvrir_Met);
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(SatMet);
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(new JLabel());
		JButton SatGPS = new JButton("Satellites GPS");
		SatGPS.addActionListener(ouvrir_GPS);
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(SatGPS);
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(new JLabel());
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(new JLabel("<html><div style='text-align: center;'>Retour aux choix de BDD</div></html>", SwingConstants.CENTER));
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(new JLabel());
		JButton Retour = new JButton("Retour à la page principale");
		Retour.addActionListener(ouvrir_Page_Acceuil);
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(Retour);
		zone_onglet_top_SeeStar_Page_Sat_StarLink.add(new JLabel());
		top_SeeStar_Page_Sat_StarLink.add(zone_onglet_top_SeeStar_Page_Sat_StarLink);
		
		// Ligne 2
		JPanel bot_SeeStar_Page_Sat_StarLink = new JPanel(new BorderLayout());
		bot_SeeStar_Page_Sat_StarLink.setBackground(new Color(40,40,40));
		scrollPane.setBorder(BorderFactory.createCompoundBorder(
			    BorderFactory.createEmptyBorder(5, 5, 5, 5),
			    BorderFactory.createLineBorder(new Color(40,40,40))
			));
		bot_SeeStar_Page_Sat_StarLink.add(scrollPane, BorderLayout.CENTER);

		//Rassemblement des lignes
		SeeStar_Page_Sat_StL.add(top_SeeStar_Page_Sat_StarLink);
		SeeStar_Page_Sat_StL.add(bot_SeeStar_Page_Sat_StarLink);

		SeeStar_Page_Sat_StL.revalidate();
		SeeStar_Page_Sat_StL.repaint();
	}
    
    private static void create_SeeStar_Page_Sat_GPS() {
    	// Création de la fenêtre d'acceuil
        SeeStar_Page_Sat_GPS = new JFrame("SeeStar - Satellites GPS");
    	
    	//Manière de fermer la fenêtre d'acceuil (quitter la fenêtre)
        SeeStar_Page_Sat_GPS.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Taille de la fenêtre (longueur, largeur)
        SeeStar_Page_Sat_GPS.setSize(800, 500);

        // Centrer les fenêtres
        SeeStar_Page_Sat_GPS.setLocationRelativeTo(null);
        
        // Création des composants de la fenêtre d'acceuil
        //Une zone de texte
		JLabel Pres_lst_sat_GPS = new JLabel("<html><div style='text-align: center;'>Voici une liste d'éléments de la base sélectionné : GPS</div></html>", SwingConstants.CENTER);
		
		// Sélection de l'URL selon le choix
		String urlCible = "https://celestrak.org/NORAD/elements/gps-ops.txt";
		ArrayList<Satellite> liste = telecharger(urlCible);

		// TABLEAU
		String[] colonnes = {"Nom", "ID", "Inclinaison"};
		DefaultTableModel model = new DefaultTableModel(colonnes, 0);
		JTable table_GPS = new JTable(model);

		// Remplissage du tableau
		for (Satellite sat : liste) {
		    model.addRow(new Object[]{
		        sat.getNom(),
		        sat.getId(),
		        sat.getInclinaison()
		    });
		}

		// Scroll
		JScrollPane scrollPane = new JScrollPane(table_GPS);

		// STYLE
		table_GPS.setRowHeight(25);
		table_GPS.setFont(new Font("Arial", Font.PLAIN, 14));
		table_GPS.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));

		// Centrer Nom + ID + Inclinaison
		DefaultTableCellRenderer center = new DefaultTableCellRenderer();
		center.setHorizontalAlignment(JLabel.CENTER);

		table_GPS.getColumnModel().getColumn(0).setCellRenderer(center);
		table_GPS.getColumnModel().getColumn(1).setCellRenderer(center);
		table_GPS.getColumnModel().getColumn(2).setCellRenderer(center);
		
		// Tri auto des lignes en cliquant dessus
		table_GPS.setAutoCreateRowSorter(true);


		// Organisation des composants de la fenêtre d'acceuil dans un layout
		SeeStar_Page_Sat_GPS.setLayout(new GridLayout(2, 1, 10, 10));

		//Ligne 1
		//Répartition en 2 colonnes
		//Colonne 1
		JPanel top_SeeStar_Page_Sat_GPS = new JPanel(new GridLayout(1, 2));
		top_SeeStar_Page_Sat_GPS.setBackground(new Color(40,40,40));
		top_SeeStar_Page_Sat_GPS.add(Pres_lst_sat_GPS);
		//Colonne 2
		JPanel zone_onglet_top_SeeStar_Page_Sat_GPS = new JPanel(new GridLayout(12,1));
		zone_onglet_top_SeeStar_Page_Sat_GPS.setBackground(new Color(40,40,40));
		zone_onglet_top_SeeStar_Page_Sat_GPS.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10),
																						  BorderFactory.createLineBorder(Color.BLACK) ));
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(new JLabel());
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(new JLabel("<html><div style='text-align: center;'>Accès aux autres onglets</div></html>", SwingConstants.CENTER));
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(new JLabel());
		JButton SatMet = new JButton("Satellittes Météo");
		SatMet.addActionListener(ouvrir_Met);
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(SatMet);
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(new JLabel());
		JButton SatStL = new JButton("Satellittes StarLink");
		SatStL.addActionListener(ouvrir_Met);
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(SatStL);
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(new JLabel());
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(new JLabel("<html><div style='text-align: center;'>Retour aux choix de BDD</div></html>", SwingConstants.CENTER));
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(new JLabel());
		JButton Retour = new JButton("Retour à la page principale");
		Retour.addActionListener(ouvrir_Page_Acceuil);
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(Retour);
		zone_onglet_top_SeeStar_Page_Sat_GPS.add(new JLabel());
		top_SeeStar_Page_Sat_GPS.add(zone_onglet_top_SeeStar_Page_Sat_GPS);
		
		// Ligne 2
		JPanel bot_SeeStar_Page_Sat_GPS = new JPanel(new BorderLayout());
		bot_SeeStar_Page_Sat_GPS.setBackground(new Color(40,40,40));
		scrollPane.setBorder(BorderFactory.createCompoundBorder(
			    BorderFactory.createEmptyBorder(5, 5, 5, 5),
			    BorderFactory.createLineBorder(new Color(40,40,40))
			));
		bot_SeeStar_Page_Sat_GPS.add(scrollPane, BorderLayout.CENTER);

		//Rassemblement des lignes
		SeeStar_Page_Sat_GPS.add(top_SeeStar_Page_Sat_GPS);
		SeeStar_Page_Sat_GPS.add(bot_SeeStar_Page_Sat_GPS);

		SeeStar_Page_Sat_GPS.revalidate();
		SeeStar_Page_Sat_GPS.repaint();
    }
    
    public static ArrayList<Satellite> telecharger(String adresseUrl) {
        ArrayList<Satellite> listeSat = new ArrayList<>();

        try {
            URL url = new URI(adresseUrl).toURL();
            Scanner sc = new Scanner(url.openStream());

            while (sc.hasNextLine()) {
                String ligne0 = sc.nextLine().trim();
                if (!sc.hasNextLine()) break;
                String ligne1 = sc.nextLine();
                if (!sc.hasNextLine()) break;
                String ligne2 = sc.nextLine();

                String id = ligne1.substring(2, 7).trim();
                String inclinaison = ligne2.substring(8, 16).trim();

                listeSat.add(new Satellite(ligne0, id, inclinaison));
            }

            sc.close();
        } catch (Exception e) {
        	listeSat.add(new Satellite("Erreur de chargement de la base", "Erreur de chargement de la base", "Erreur de chargement de la base"));
            e.printStackTrace();
        }

        return listeSat;
    }

}
