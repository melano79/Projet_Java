package MP;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import java.sql.Connection;
import java.sql.DriverManager;

public class Start {

    static Commandes_guide com = new Commandes_guide(); // ✔️ Correction : static

    // Méthode principale de démarrage du programme
    static void debut(Scanner scanner, String url) throws SQLException {

        // Boucle principale du programme (tourne jusqu'à "exit")
        while (true) {

            // Connexion à la base SQLite via l'URL fournie
            Connection conn = DriverManager.getConnection(url);
            System.out.println("Connexion établie avec la base SQLite.");

            // Création d'un Statement pour exécuter des requêtes SQL
            Statement stmt = conn.createStatement();

            // Message d'accueil
            System.out.println("Bonjour bienvenu dans seastars");

            // Menu des commandes disponibles
            System.out.print("Commande : \n");
            System.out.print("f1 : terminal de commandes\n");
            System.out.print("play : terminal graphique\n");
            System.out.print("exit : quiter\n");

            // Lecture de la commande entrée par l'utilisateur
            String cmd = scanner.nextLine();

            // Sélection de l'action selon la commande
            switch (cmd) {

                case "f1":
                    Sqlitecmd.commandeseuls(scanner, stmt);
                    break;

                case "play":
                    com.commandesGuide(scanner, stmt);
                    return;

                case "exit":
                    System.out.println("Fin du programme.");
                    return;

                default:
                    System.out.println("Commande inconnue.");
            }

            // Fermeture du Statement et de la connexion
            stmt.close();
            conn.close();
        }
    }
}
