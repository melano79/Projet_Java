package MP;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Sqlitecmd {
    
    // Méthode qui gère le "terminal SQL" maison
    // - Scanner : pour lire les commandes de l'utilisateur
    // - Statement : pour exécuter les requêtes SQL
    // - throws SQLException : laisse la gestion des erreurs au code appelant
    static void commandeseuls(Scanner scanner, Statement stmt) throws SQLException {

        // Boucle principale du terminal SQL
        while (true) {

            System.out.println("faire requête SQL avec (*)\n");

            // Lecture de la requête SQL entrée par l'utilisateur Exemple : SELECT * FROM Joueur;
            String executequery = scanner.nextLine();

            // Exécution de la requête SQL ResultSet contient les résultats retournés par la base
            ResultSet rs = stmt.executeQuery(executequery);

            // Demande à l'utilisateur quelle colonne afficher
            System.out.println("que voulez vous afficher? \n");
            String nextaffichage = scanner.nextLine();

            System.out.println("il sera affiché : " + nextaffichage + " ;");

            // Parcours des résultats ligne par ligne
            // rs.next() avance dans le tableau de résultats
            while (rs.next()) {
                // Affiche la valeur de la colonne demandée
                System.out.println(rs.getString(nextaffichage));
            }

            // Fermeture du ResultSet (bonne pratique)
            rs.close();

            // Demande si l'utilisateur veut exécuter une nouvelle commande
            System.out.println("voulez vous faire une nouvelle commande (0 = non / 1 = oui) :");

            // Lecture du choix (0 ou 1)
            int again = scanner.nextInt();

            // Important : vider le retour à la ligne laissé par nextInt()
            scanner.nextLine();

            // Si l'utilisateur tape 0 → on quitte la boucle
            if (again == 0) {
                break;
            }
        }
    }
}
