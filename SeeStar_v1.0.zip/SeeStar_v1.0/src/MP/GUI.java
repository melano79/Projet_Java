package MP;

import java.util.Scanner;

public class GUI {

    public static void main(String[] args) {
        // Toujours lancer l'interface graphique dans l'Event Dispatch Thread
    	
    	System.out.println("---------------------------- Binevenu dans SeeStar -----------------------------");
    	System.out.println("Souhaitez-vous utilisez la Base de Données locale ou la Base de Données distante");
    	System.out.println("                           (travail sur console)         (travail en graphique)");
    	System.out.println("                               (entrez 0)                      (entrez 1)");
    	
    	try (Scanner scanner = new Scanner(System.in)) {
			int res = scanner.nextInt();
			switch (res) {
			case 0:
				MainLoc Loc = new MainLoc();
				Loc.main();
			case 1:
			    Interface BDD_Dist = new Interface();
			    BDD_Dist.create();	
			}
		}
    }
}
