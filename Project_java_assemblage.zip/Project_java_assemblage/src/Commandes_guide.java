import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Commandes_guide {

    static void commandesGuide(Scanner clavier, Statement requeteSQL) throws SQLException {

        while (true) {
            System.out.println("==============================================");
            System.out.println("   BIENVENUE DANS LES COMMANDES GUIDÉES");
            System.out.println("==============================================\n");

            System.out.println("Souhaitez-vous afficher un type de satellite en particulier ?");
            System.out.println("(Exemples : Starlink, NASA, ESA, China, etc.)");
            System.out.println("Laissez vide pour afficher tous les satellites.");
            System.out.print("Votre choix : ");
            String demandesate = clavier.nextLine().trim();

            String conditionFiltre = "";
            if (!demandesate.equals("")) {
                conditionFiltre = "WHERE [Operator_Owner;] LIKE '%" + demandesate + "%' "
                                + "OR [Name_of_Satellite;] LIKE '%" + demandesate + "%' "
                                + "OR [Users;] LIKE '%" + demandesate + "%'";
            }

            System.out.println("\nCombien de satellites voulez-vous afficher ?");
            System.out.print("Votre choix : ");
            int limite = 10;
            try {
                limite = clavier.nextInt();
            } catch (Exception e) {
                System.out.println("Commande inconnue. Valeur par défaut : 10 satellites.");
                limite = 10;
            }
            clavier.nextLine();

            // 🔹 Appel de la classe d’affichage
            Affichage_satellite.afficherListe(requeteSQL, conditionFiltre, limite);

            System.out.println("\nVoulez-vous faire une nouvelle commande ? (0 = non / 1 = oui)");
            int recommencer = clavier.nextInt();
            clavier.nextLine();

            if (recommencer == 0) {
                System.out.println("Retour au menu principal...");
                String url = "jdbc:sqlite:C:\\Users\\mathi\\Desktop\\java_db\\chiant.db";
                Start.debut(clavier, url);
                break;
            }
        }
    }
}
