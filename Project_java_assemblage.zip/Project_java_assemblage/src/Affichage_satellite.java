import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Affichage_satellite {

    static void afficherListe(Statement requeteSQL, String conditionFiltre, int limite) throws SQLException {

        String requete = "SELECT [Users;], [Name_of_Satellite;], [Operator_Owner;], [Inclination;], "
                       + "[Date_of_Launch;], [Expected_Lifetime_yrs;], [Contractor;], [Comments;], "
                       + "[Launch_Site;], [Power_watts;], [Launch_Mass_kg;], [Type_of_Orbit;] "
                       + "FROM NewTable " + conditionFiltre + " LIMIT " + limite + ";";

        try {
            ResultSet rs = requeteSQL.executeQuery(requete);

            System.out.println("\n==============================================");
            System.out.println("           LISTE DES SATELLITES");
            System.out.println("==============================================\n");

            int compteur = 0;
            while (rs.next()) {
                compteur++;
                System.out.println("Satellite n°" + compteur);
                afficherSatellite(rs);
                System.out.println("----------------------------------------------");
            }

            rs.close();

            if (compteur == 0) {
                System.out.println("Aucun satellite trouvé avec ce filtre.");
            }

        } catch (SQLException e) {
            System.out.println("Erreur SQL : " + e.getMessage());
        }
    }

    static void afficherSatellite(ResultSet rs) throws SQLException {
        System.out.println(" - Utilisateurs : " + rs.getString("Users;"));
        System.out.println(" - Nom du satellite : " + rs.getString("Name_of_Satellite;"));
        System.out.println(" - Propriétaire / Opérateur : " + rs.getString("Operator_Owner;"));
        System.out.println(" - Inclinaison : " + rs.getString("Inclination;"));
        System.out.println(" - Date de lancement : " + rs.getString("Date_of_Launch;"));
        System.out.println(" - Durée de vie prévue : " + rs.getString("Expected_Lifetime_yrs;"));
        System.out.println(" - Constructeur : " + rs.getString("Contractor;"));
        System.out.println(" - Commentaires : " + rs.getString("Comments;"));
        System.out.println(" - Site de lancement : " + rs.getString("Launch_Site;"));
        System.out.println(" - Puissance (watts) : " + rs.getString("Power_watts;"));
        System.out.println(" - Masse (kg) : " + rs.getString("Launch_Mass_kg;"));
        System.out.println(" - Type d’orbite : " + rs.getString("Type_of_Orbit;"));
    }
}
