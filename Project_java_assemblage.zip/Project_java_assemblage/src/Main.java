


import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
       

        // Scanner pour lire les entrées utilisateur dans toute l'application
        Scanner scanner = new Scanner(System.in);

        // URL de connexion vers ta base SQLite locale
        String url = "jdbc:sqlite:C:\\Users\\mathi\\Desktop\\java_db\\chiant.db";

        // Boucle principale permettant de relancer le programme en cas d'erreur SQL
        while (true) {
            try {
                // Lancement du programme principal (menu + logique)
                Start.debut(scanner, url);

                // Si Start.debut() se termine sans erreur → on sort de la boucle
                break;

            } catch (SQLException e) {

                // Affichage de l'erreur SQL rencontrée
                System.err.println("Erreur SQL : " + e.getMessage());

                // Demande à l'utilisateur s'il veut relancer le programme
                System.out.println("Voulez-vous retenter ? (1 = oui)");

                // Lecture de la réponse utilisateur (sous forme de texte)
                String scans = scanner.nextLine();

                // Si l'utilisateur tape "1", on relance la boucle
                if (scans.equals("1")) {
                    System.out.println("Redémarrage du programme...\n");

                } else {
                    // Sinon, on quitte la boucle et donc le programme
                    break;
                }
            }
        }

        // Fermeture du scanner
        scanner.close();
    }
}
