

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


import java.sql.Connection;
import java.sql.DriverManager;

public class Start {

    // Méthode principale de démarrage du programme
    // - scanner : pour lire les commandes utilisateur
    // - url : chemin JDBC vers ta base SQLite
    // - throws SQLException : laisse la gestion des erreurs au code appelant
    static void debut(Scanner scanner, String url) throws SQLException {

        // Boucle principale du programme (tourne jusqu'à "exit")
        while (true) {

            // Connexion à la base SQLite via l'URL fournie
            Connection conn = DriverManager.getConnection(url);
            System.out.println("Connexion établie avec la base SQLite.");

            // Création d'un Statement pour exécuter des requêtes SQL
            Statement stmt = conn.createStatement();

            // Message d'accueil
            System.out.println("bonjour bienvenus dans seastars");

            // Menu des commandes disponibles
            System.out.print("Commande : \n");
            System.out.print("f1 : terminal de commandes\n");
            System.out.print("play : terminal graphique\n");
            System.out.print("exit : quiter\n");

            // Lecture de la commande entrée par l'utilisateur
            String cmd = scanner.nextLine();

            // Sélection de l'action selon la commande
            switch (cmd) {

                case "f1":
                    // Appel du terminal SQL personnalisé
                    Sqlitecmd.commandeseuls(scanner, stmt);
                    break;
                case "play":
                    return;

                case "exit":
                    // Sortie propre du programme
                    System.out.println("Fin du programme.");
                    return;

                default:
                    // Commande non reconnue
                    System.out.println("Commande inconnue.");
            }

            // Fermeture du Statement et de la connexion
            // (bonne pratique pour éviter les fuites de ressources)
            stmt.close();
            conn.close();
        }
    }
}

