import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Commandes_guide {

    // Méthode principale appelée depuis Start (case "play")
    static void commandesGuide(Scanner clavier, Statement requeteSQL) throws SQLException {

        while (true) {

            System.out.println("==============================================");
            System.out.println("   BIENVENUE DANS LES COMMANDES GUIDÉES");
            System.out.println("==============================================\n");

            // Demande du type de satellite
            System.out.println("Souhaitez-vous afficher un type de satellite en particulier ?");
            System.out.println("(Exemples : Starlink, NASA, ESA, China, etc.)");
            System.out.println("Tapez * ou laissez vide pour afficher tous les satellites.");
            System.out.print("Votre choix : ");
            String demandesate = clavier.nextLine().trim();

            // Construction du filtre SQL
            String conditionFiltre = "";
            
            
            
            

            // Si vide de ou * pas de conditionFiltre
            if (!demandesate.equals("") && !demandesate.equals("*")) {
                conditionFiltre = "WHERE [Operator_Owner;] LIKE '%" + demandesate + "%' "
                                + "OR [Name_of_Satellite;] LIKE '%" + demandesate + "%' "
                                + "OR [Users;] LIKE '%" + demandesate + "%'";
            }

            // Choix du nombre de satellites à afficher
            System.out.println("\nCombien de satellites voulez-vous afficher ?");
            System.out.print("Votre choix : ");

            int limite = 10; // valeur par défaut
            try {
                limite = clavier.nextInt(); // lecture du nombre
            } catch (Exception e) {
                System.out.println("Commande inconnue. Valeur par défaut : 10 satellites.");
                limite = 10;
            }
            clavier.nextLine(); // vider le buffer

            //Choix du mode d’affichage
            System.out.println("\nChoisissez le type d’affichage :");
            System.out.println("1 - Affichage général");
            System.out.println("2 - Par date de lancement");
            System.out.println("3 - Par puissance (watts)");
            System.out.println("4 - Par poids (kg)");
            System.out.println("5 - Par type d’orbite");
            System.out.println("6 - Par site de lancement");
            System.out.println("7 - Par commentaires");
            System.out.print("Votre choix : ");
            
            int choixAffichage = 1;

            while (true) {
                try {
                    System.out.print("Entrez un entier : ");
                    choixAffichage = clavier.nextInt();
                    break; // sortie de boucle si OK
                } catch (Exception e) {
                    System.out.println("Erreur : veuillez entrer un nombre entier !");
                    clavier.nextLine(); // vide le buffer pour éviter boucle infinie
                }
            }
            
            Affichage_satellite.afficher(requeteSQL, conditionFiltre, limite, clavier, choixAffichage);
            
            

            //Demande si l'utilisateur veut recommencer
            System.out.println("\nVoulez-vous faire une nouvelle commande ? (0 = non / 1 = oui)");
            int recommencer = clavier.nextInt();
            clavier.nextLine(); // vider le retour à la ligne
            
            
            

            if (recommencer == 0) {
                System.out.println("Retour au menu principal...");
                String url = "jdbc:sqlite:C:\\Users\\mathi\\Desktop\\java_db\\chiant.db";
                Start.debut(clavier, url);
                break;
            }
        }
    }
}
