import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Affichage_satellite {

    // ============================================================
    //  AFFICHAGE TRIE 
    // ============================================================
	static void afficher(Statement requeteSQL, String conditionFiltre, int limite, Scanner clavier, int choixAffichage) throws SQLException {

	    String choix = "";
	    String requete = "";

	    switch(choixAffichage) {

	        case 1:
	            choix = "";
	            requete = "SELECT * FROM NewTable "
	   	             + conditionFiltre
		             + " LIMIT " + limite + ";";
	            
	            break;

	        case 2:
	            choix = "[Date_of_Launch;]"; // NVARCHAR
	            requete = commandesqlNVARCHAR(limite, conditionFiltre, choix);
	            break;

	        case 3:
	            choix = "[Power_watts;]"; // NVARCHAR
	            requete = commandesqlNVARCHAR(limite, conditionFiltre, choix);
	            break;

	        case 4:
	            choix = "[Launch_Mass_kg;]"; // NVARCHAR
	            requete = commandesqlNVARCHAR(limite, conditionFiltre, choix);
	            break;

	        case 5:
	            choix = "[Type_of_Orbit;]"; // NVARCHAR
	            requete = commandesqlNVARCHAR(limite, conditionFiltre, choix);
	            break;

	        case 6:
	            choix = "[Launch_Site;]"; // VARCHAR
	            requete = commandesql(limite, conditionFiltre, choix);
	            break;

	        case 7:
	            choix = "[Comments;]"; // VARCHAR
	            requete = commandesql(limite, conditionFiltre, choix);
	            break;
	        default : 
	        	System.out.println("Commande inconnue! default (Affichage général)"); 
	        	 choix = "";
		         requete = "SELECT * FROM NewTable "
		   	             + conditionFiltre
			             + " LIMIT " + limite + ";";
		            
		        break;
	    }

	    // Exécution
	    ResultSet rs = requeteSQL.executeQuery(requete);

	    int compteur = 0;
	    while (rs.next()) {
	        compteur++;
	        System.out.println("Satellite n°" + compteur);
	        afficherSatelliteComplet(rs);
	    }

	    rs.close();
	    
	    if ( compteur == 0) {
	    	 System.out.println("aucun Satellite trouvé!");
	    }
	}
   
	static String commandesqlNVARCHAR(int limite, String conditionFiltre, String choix) throws SQLException {

		if (conditionFiltre.equals("")) {
			  return "SELECT * FROM NewTable "
				         + " WHERE "+ choix +" IS NOT NULL "
				         + " ORDER BY CAST(" + choix + " AS REAL) DESC "
				         + " LIMIT " + limite + ";";
		} else {
		    return "SELECT * FROM NewTable "
			         +  conditionFiltre + " AND " + choix + " IS NOT NULL "
			         + " ORDER BY CAST(" + choix + " AS REAL) DESC "
			         + " LIMIT " + limite + ";";
		}
	}



    
	static String commandesql(int limite, String conditionFiltre, String choix) throws SQLException {

	    if (conditionFiltre.equals("")) {
	        return "SELECT * FROM NewTable "
	        	 + " WHERE "+ choix +" IS NOT NULL "
	        	 + " ORDER BY " + choix 
	             + " LIMIT " + limite + ";";
	    }else {
		
	    return "SELECT * FROM NewTable "
	         + conditionFiltre
	         + " AND " + choix + " IS NOT NULL "
	         + " ORDER BY " + choix + " ASC "
	         + " LIMIT " + limite + ";";
	    }
	}

    
    

    // ============================================================
    //  AFFICHAGE COMPLET D’UN SATELLITE (appelé par toutes les méthodes)
    // ============================================================
    static void afficherSatelliteComplet(ResultSet rs) throws SQLException {

        // Chaque champ correspond à une colonne de ta table SQLite
        System.out.println(" - Utilisateurs : " + rs.getString("Users;"));
        System.out.println(" - Nom du satellite : " + rs.getString("Name_of_Satellite;"));
        System.out.println(" - Propriétaire / Opérateur : " + rs.getString("Operator_Owner;"));
        System.out.println(" - Inclinaison : " + rs.getString("Inclination;"));
        System.out.println(" - Date de lancement : " + rs.getString("Date_of_Launch;"));
        System.out.println(" - Durée de vie prévue : " + rs.getString("Expected_Lifetime_yrs;"));
        System.out.println(" - Constructeur : " + rs.getString("Contractor;"));
        System.out.println(" - Commentaires : " + rs.getString("Comments;"));
        System.out.println(" - Site de lancement : " + rs.getString("Launch_Site;"));
        System.out.println(" - Puissance (watts) : " + rs.getString("Power_watts;"));
        System.out.println(" - Masse (kg) : " + rs.getString("Launch_Mass_kg;"));
        System.out.println(" - Type d’orbite : " + rs.getString("Type_of_Orbit;"));
        System.out.println("----------------------------------------------");
    }
}
